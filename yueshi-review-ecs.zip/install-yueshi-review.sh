#!/usr/bin/env bash
set -euo pipefail

APP_NAME="yueshi-review"
APP_DIR="/opt/yueshi-review/current"
ENV_FILE="/etc/yueshi-review.env"
SERVICE_FILE="/etc/systemd/system/yueshi-review.service"
NGINX_FILE="/etc/nginx/conf.d/yueshi-review.conf"
SERVER_IP="47.239.12.230"
PORT="5178"

if [ "$(id -u)" != "0" ]; then
  echo "请用 root 用户执行：sudo bash install-yueshi-review.sh"
  exit 1
fi

mkdir -p "$APP_DIR"
cp -R ./assets "$APP_DIR/"
cp ./index.html "$APP_DIR/index.html"
cp ./server.mjs "$APP_DIR/server.mjs"
cp ./llm-project-knowledge.json "$APP_DIR/llm-project-knowledge.json"

if ! command -v node >/dev/null 2>&1; then
  echo "未检测到 Node.js，请先安装 Node.js 20 或 22。"
  exit 1
fi

if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<'EOF'
DEEPSEEK_API_KEY=请在这里填你的DeepSeekKey
DEEPSEEK_MODEL=deepseek-v4-flash
PORT=5178
EOF
  chmod 600 "$ENV_FILE"
  echo "已创建 $ENV_FILE，请先填入真实 DEEPSEEK_API_KEY 后再启动服务。"
fi

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Yueshi Review Helper
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$(command -v node) $APP_DIR/server.mjs
Restart=always
RestartSec=3
User=root

[Install]
WantedBy=multi-user.target
EOF

python3 - <<'PY'
from pathlib import Path

block = """    location /review-helper/ {
        proxy_pass http://127.0.0.1:5178/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

"""

paths = []
for root in (Path("/etc/nginx/conf.d"), Path("/etc/nginx/sites-enabled"), Path("/etc/nginx/sites-available")):
    if root.exists():
        paths.extend([p for p in root.rglob("*") if p.is_file()])

target = None
for path in paths:
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    if "127.0.0.1:4173" in text:
        target = path
        break

if target:
    text = target.read_text(encoding="utf-8")
    backup = target.with_suffix(target.suffix + ".bak-yueshi-review")
    backup.write_text(text, encoding="utf-8")
    if "location /review-helper/" not in text:
        marker = "    location / {"
        if marker in text:
            text = text.replace(marker, block + marker, 1)
        else:
            pos = text.rfind("}")
            if pos < 0:
                raise SystemExit(f"Nginx 配置无法自动写入：{target}")
            text = text[:pos] + block + text[pos:]
        target.write_text(text, encoding="utf-8")
    print(f"已更新 Nginx 配置：{target}")
else:
    fallback = Path("/etc/nginx/conf.d/yueshi-review.conf")
    fallback.write_text("""server {
    listen 80;
    server_name 47.239.12.230;

    location /review-helper/ {
        proxy_pass http://127.0.0.1:5178/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
""", encoding="utf-8")
    print(f"未找到门店反馈 Nginx 配置，已创建独立配置：{fallback}")
PY

systemctl daemon-reload

if grep -q "请在这里填你的DeepSeekKey" "$ENV_FILE"; then
  echo "还没有启动服务：请编辑 $ENV_FILE 填入 DEEPSEEK_API_KEY，然后执行："
  echo "systemctl enable --now yueshi-review"
  echo "nginx -t && systemctl reload nginx"
  exit 0
fi

systemctl enable --now yueshi-review
nginx -t
systemctl reload nginx

echo "部署完成："
echo "员工扫码入口：http://$SERVER_IP/review-helper/"
echo "客户生成入口：http://$SERVER_IP/review-helper/?customer=1"
