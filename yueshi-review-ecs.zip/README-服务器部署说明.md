# 玥时之肤好评助手 ECS 部署说明

## 部署目标

把好评助手从“GitHub Pages 前端 + 阿里云函数后端”迁移为：

- 门店反馈继续占用服务器根路径：`http://47.239.12.230/`
- 好评助手占用独立路径：`http://47.239.12.230/review-helper/`
- 好评生成接口由服务器常驻 Node 服务处理，再正常调用 DeepSeek 快速版

这样可以不再依赖阿里云函数，但 DeepSeek 大模型仍正常调用。

## 服务器路径

- 应用目录：`/opt/yueshi-review/current`
- 环境变量：`/etc/yueshi-review.env`
- systemd 服务：`yueshi-review.service`
- Nginx 配置：`/etc/nginx/conf.d/yueshi-review.conf`
- 服务端口：`127.0.0.1:5178`

## 上传后执行

在服务器解压部署包后进入目录，执行：

```bash
sudo bash install-yueshi-review.sh
```

第一次执行后，如果提示需要填写 DeepSeek Key：

```bash
sudo nano /etc/yueshi-review.env
```

填好：

```text
DEEPSEEK_API_KEY=你的真实Key
DEEPSEEK_MODEL=deepseek-v4-flash
PORT=5178
```

然后执行：

```bash
sudo systemctl enable --now yueshi-review
sudo nginx -t
sudo systemctl reload nginx
```

## 测试地址

- 员工入口：`http://47.239.12.230/review-helper/`
- 客户入口：`http://47.239.12.230/review-helper/?customer=1`
- 接口测试：`http://47.239.12.230/review-helper/api/generate-review`

## 注意

- 当前二维码指向 IP 地址版本，后续绑定域名和 HTTPS 后，需要重新生成二维码。
- 不要把 DeepSeek Key 写入前端文件、GitHub 或文字记录。
- 服务器根路径已经给门店反馈使用，不要覆盖 `/opt/yueshi-feedback/current`。
